<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    
<?php if( chiron_get_option('preload') != false ){ ?>
    <div id="royal_preloader"></div>
<?php } ?>
    <!-- Nav and Logo
    ================================================== -->

    <nav id="menu-wrap" class="menu-back cbp-af-header">
        <div class="menu">
            <a class="logo-1" href="<?php echo esc_url( home_url('/') ); ?>" >
                <div class="logo" style="background-image: url('<?php echo esc_url( chiron_get_option( 'logo' ) ); ?>')"></div>
            </a>
            <a class="logo-2" href="<?php echo esc_url( home_url('/') ); ?>" >
                <div class="logo" style="background: url('<?php echo esc_url( chiron_get_option( 'logo_scroll' ) ); ?>') no-repeat center center;">
                </div>
            </a>
            <?php
                $primary = array(
                    'theme_location'  => 'primary',
                    'menu'            => '',
                    'container'       => '',
                    'container_class' => '',
                    'container_id'    => '',
                    'menu_class'      => '',
                    'menu_id'         => '',
                    'echo'            => true,
                    'fallback_cb'     => 'chiron_bootstrap_navwalker::fallback',
                    'walker'          => new chiron_bootstrap_navwalker(),
                    'before'          => '',
                    'after'           => '',
                    'link_before'     => '',
                    'link_after'      => '',
                    'items_wrap'      => '<ul>%3$s</ul>',
                    'depth'           => 0,
                );
                if ( has_nav_menu( 'primary' ) ) {
                    wp_nav_menu( $primary );
                }
            ?>
        </div>
    </nav>
<main class="over-hide">