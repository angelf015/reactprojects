<a href="<?php the_permalink(); ?>" class="no-lines tipped" data-title="<em><?php the_time( get_option( 'date_format' ) ); ?></em> <span><?php esc_html_e('by ','chiron'); ?> <?php the_author(); ?></span>" data-tipper-options='{"direction":"top","follow":"true","margin":10}'>
    <div id="post-<?php the_ID(); ?>" <?php post_class('blog-box'); ?> >
        <?php if( function_exists( 'rwmb_meta' ) ) { ?>
          <?php $images = rwmb_meta( '_cmb_images', "type=image" ); ?>
          <?php if($images){ ?>                  
              <?php foreach ( $images as $image ) { ?>
                <?php $img = $image['full_url']; ?>
                <div class="item"><img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></div> 
              <?php } ?>                                     
          <?php } ?>
        <?php } ?>
        <h6><?php the_title(); ?></h6>
        <p><?php echo chiron_excerpt_length(); ?></p>
        <div class="more"><?php esc_html_e('More','chiron'); ?></div>
    </div>
</a>
