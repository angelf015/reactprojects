<a href="<?php the_permalink(); ?>" class="no-lines tipped" data-title="<em><?php the_time( get_option( 'date_format' ) ); ?></em> <span><?php esc_html_e('by ','chiron'); ?> <?php the_author(); ?></span>" data-tipper-options='{"direction":"top","follow":"true","margin":10}'>
    <div id="post-<?php the_ID(); ?>" <?php post_class('blog-box'); ?> >
        <?php if( function_exists( 'rwmb_meta' ) ) { ?>
        <?php echo rwmb_meta( '_cmb_link_video', 'type=oembed' ); // if you want get url: $url = get_post_meta( get_the_ID(), '_cmb_link_video', true ); echo $url; ?> 
        <?php } ?>
        <h6><?php the_title(); ?></h6>
        <p><?php echo chiron_excerpt_length(); ?></p>
        <div class="more"><?php esc_html_e('More','chiron'); ?></div>
    </div>
</a>