<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header(); ?>

<!-- subheader begin -->
<div class="section padding-top-hero padding-bottom-big over-hide">
	<div class="container">
		<div class="row">
			<div class="col-md-12 page-center-text-wrap text-center">
				<?php while ( have_posts() ) : the_post(); ?>
				<h1 class="parallax-fade-top-2"><strong>-</strong> <?php esc_html_e('by ','chiron'); ?> <?php the_author(); ?> <strong>-</strong><br><span><?php the_title(); ?></span></h1>
				<?php endwhile; ?>
			</div>	
		</div>		
	</div>	
</div>	
<!-- subheader close -->

<!-- content begin -->
<div class="section padding-bottom-big">
	<div class="container">
		<div class="row">
		    <?php if(chiron_get_option('single_layout')== 'left-bar'){ ?>
	        <div class="col-lg-4 mt-4 mt-lg-0">   
	            <div class="sidebar-box background-white drop-shadow rounded">                
	                <?php get_sidebar(); ?>
	            </div>
	        </div>
	        <?php } ?> 
		    <div class="<?php if( chiron_get_option('blog_layout') == 'no-bar' ){ echo 'col-md-12'; }else{ echo 'col-md-8'; } ?>">
		    	<div class="section drop-shadow rounded">
		    		<div class="post-box background-white over-hide">
						<?php 
							/* Start the Loop */
							while ( have_posts() ) : the_post(); 
						?>    
		                	<?php $link_audio = get_post_meta(get_the_ID(),'_cmb_link_audio', true); ?>
		                    <?php if ( 'audio' == get_post_format() ) { ?>
		                    	<div class="post-audio">
						            <iframe style="width:100%;border:none;" height="150" scrolling="no" src="<?php echo esc_url( $link_audio ); ?>"></iframe>
						        </div> 
		                    <?php }elseif ( 'gallery' == get_post_format() ) { ?>
		                    	<div id="owl-blog-slider" class="owl-carousel owl-theme">
						            <?php if( function_exists( 'rwmb_meta' ) ) { ?>
						              <?php $images = rwmb_meta( '_cmb_images', "type=image" ); ?>
						              <?php if($images){ ?>                  
						                  <?php foreach ( $images as $image ) { ?>
						                    <?php $img = $image['full_url']; ?>
						                    <div class="item"><img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></div> 
						                  <?php } ?>                                     
						              <?php } ?>
						            <?php } ?>
						        </div>		                    
		                    <?php }elseif ( 'video' == get_post_format() ) { ?>
		                    	<div class="post-video">
						            <?php if( function_exists( 'rwmb_meta' ) ) { ?>
								    <?php $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true); if($link_video) { ?>
								    <?php echo rwmb_meta( '_cmb_link_video', 'type=oembed' ); // if you want get url: $url = get_post_meta( get_the_ID(), '_cmb_link_video', true ); echo $url; ?>
								<?php } } ?>      
						        </div>
		                    <?php }elseif ( 'image' == get_post_format() ) { ?>
		                    	<div class="post-image">
						            <?php if( function_exists( 'rwmb_meta' ) ) { ?>
						                <?php $images = rwmb_meta( '_cmb_image', "type=image" ); ?>
						                <?php if($images != ''){ ?>              
						                    <?php  foreach ( $images as $image ) {  ?>
						                        <?php $img = $image['full_url']; ?>
						                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="blog-home-img">
						                    <?php } ?>                
						                <?php }else{ ?>
						                    <?php 
						                        if( has_post_thumbnail() ){               
						                             the_post_thumbnail( 'full' ); 
						                        } 
						                    ?>
						                <?php } ?>
						            <?php } ?>
						        </div>   
		                    <?php }else{ ?>              	
		                    	<div class="post-image">						            
				                    <?php 
				                        if( has_post_thumbnail() ){               
				                             the_post_thumbnail( 'full' ); 
				                        } 
				                    ?>
						        </div> 
		                    <?php } ?>

				       	<div class="padding-in">    
		                    <?php the_content(); ?>
		                </div>
 							<?php
		                    wp_link_pages( array(
		                        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'chiron' ) . '</span>',
		                        'after'       => '</div>',
		                        'link_before' => '<span class="numbers-page">',
		                        'link_after'  => '</span>',
		                        'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'chiron' ) . ' </span>%',
		                        'separator'   => '<span class="screen-reader-text">, </span>',
		                    ) );
		                	?>
				       	<div class="padding-in">
							<?php if(get_the_tag_list()) { ?>
						       	<div class="separator-wrap pt-4 pb-4">	
									<span class="separator"><span class="separator-line dashed"></span></span>
								</div>  
	                              <?php echo get_the_tag_list('<ul class="tag-list"><li>','</li><li>','</a></li></ul>'); ?>
	                         <?php } ?>
	                        <div class="separator-wrap pt-4 pb-4">	
								<span class="separator"><span class="separator-line dashed"></span></span>
							</div>
	                    	<div class="author-wrap">
								<?php echo get_avatar($comment,$size='60',$default='http://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=180' ); ?>
								<p> <?php esc_html_e('by ','chiron'); ?> <?php the_author_posts_link(); ?></p>
							</div>
                    	</div>
				       	<?php endwhile; // End of the loop. ?>  
			       </div>
		       	</div>
		       	<?php 
			       	if ( comments_open() || get_comments_number() ){ 
							// If comments are open or we have at least one comment, load up the comment template.
								comments_template();
					} 
				?>
		    </div>
		    <?php if(chiron_get_option('single_layout')== 'right-bar'){ ?>
	        <div class="col-lg-4 mt-4 mt-lg-0">   
	            <div class="sidebar-box background-white drop-shadow rounded">                
	                <?php get_sidebar(); ?>
	            </div>
	        </div>
	        <?php } ?>  
        </div>    	   	
	</div>
</div> 

<?php if(chiron_get_option('clientlogo_switch')==true ){ ?>
<div class="section padding-top-bottom-small background-dark">
    <div class="container">
        <div class="row logo-section">
            <?php $logo = chiron_get_option( 'clients_logo', array() ); ?>
            <?php foreach ( $logo as $logos ) {
              $img   = wp_get_attachment_image_src($logos['logo_img'],'full');
              $img   = $img[0];  
            ?>                                  
                <div class="col-sm-6 col-md-4 col-xl-2">
                    <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                </div>                     
            <?php } ?>
        </div>      
    </div>  
</div>
<?php } ?>
<!-- content close -->

<?php get_footer();
