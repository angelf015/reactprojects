<?php

$atts  = array_merge( array(
	'number' => 8,
	'columns' => 4,
	'type' => 'recent_products',
	'categories' => '',
	'layout_type' => 'grid',
	'rows' => 1
), $atts);
extract( $atts );

if ( empty($type) ) {
	return ;
}

$categories = apus_themer_multiple_fields_to_array_helper($categories);
$loop = alit_get_products( $categories, $type, 1, $number );

?>
<div class="widget widget-<?php echo esc_attr($layout_type); ?> widget-products products">
	<?php if ($title) { ?>
		<div class="widget-title">
			<h3><?php echo trim($title); ?></h3>
		</div>
	<?php } ?>
	<?php if ( $loop->have_posts() ) : ?>
		<div class="widget-content woocommerce">
			<div class="<?php echo esc_attr( $layout_type ); ?>-wrapper">
				<?php wc_get_template( 'layout-products/'.$layout_type.'.php' , array( 'loop' => $loop, 'columns' => $columns ) ); ?>
			</div>
			<?php if ($show_view_more_btn) { ?>
				<a href="<?php echo esc_url($view_more_btn_url); ?>"><?php echo trim($view_more_btn); ?></a>
			<?php } ?>
		</div>
	<?php endif; ?>

</div>
