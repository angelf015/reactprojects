<?php
/**
 * Additional features to allow styling of the templates
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @since Chiron 1.0
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function chiron_body_classes( $classes ) {

	// Add a class if there is a custom header.
	if ( chiron_get_option('preload') != false ){
		$classes[] = 'royal_preloader';
	}
	return $classes;
}
add_filter( 'body_class', 'chiron_body_classes' );


//Code Visual Composer.
// Add new Param in Row
if(function_exists('vc_add_param')){
	vc_add_param(
		'vc_row',
		array(
			"type" => "dropdown",
			"heading" => esc_html__('Setup Full width For Row', 'chiron'),
			"param_name" => "fullwidth",
			"value" => array(   
			                esc_html__('No', 'chiron') => 'no',  
			                esc_html__('Yes', 'chiron') => 'yes',                                                                                
			              ),
			"description" => esc_html__("Select Full width for row : yes or not, Default: No fullwidth", 'chiron'),      
        )
    );    
	vc_add_param('vc_row',array(
          "type" => "checkbox",
          "heading" => esc_html__('Use Background Image Parallax', 'chiron'),
          "param_name" => "parallax_bg",
          "value" => '',
          "description" => esc_html__("If checked columns will use background parallax.", "chiron"),      
        ) 
    );
	vc_add_param('vc_row',array(
	      'type' => 'attach_image',
	      'heading' => esc_html__( 'Image', 'chiron' ),
	      'param_name' => 'parallax_bg_image',
	      'value' => '',
	      'description' => esc_html__( 'Select image from media library.', 'chiron' ),
	      'dependency' => array(
	          'element' => 'parallax_bg',
	          'not_empty' => true,
	        ),     
	    ) 
    );
    vc_add_param(
		'vc_row',
		array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Center Wrap', 'chiron' ),
			'param_name' => 'centerwrap',
			'description' => esc_html__( 'If checked row will be set to center wrap.', 'chiron' ),
			'value' => array( esc_html__( 'Yes', 'chiron' ) => 'yes' ),
		)
    );  
    vc_add_param(
		'vc_row',
		array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Button Scroll', 'chiron' ),
			'param_name' => 'btnscroll',
			'description' => esc_html__( 'If checked row will be set to button.', 'chiron' ),
			'value' => array( esc_html__( 'Yes', 'chiron' ) => 'yes' ),
		)
    );  
	vc_add_param(
		'vc_row',
		array(
			"type" => "textfield",
			"heading" => esc_html__('Text Button Scroll', 'chiron'),
			"param_name" => "btn_text_scroll",
			"value" => "",
			"description" => esc_html__("Add text button scroll.", 'chiron'),  
		  	"dependency"  => array( 'element' => 'btnscroll', 'not_empty' => true, ),     
        )
    );   
	vc_add_param(
		'vc_row',
		array(
			"type" => "textfield",
			"heading" => esc_html__('link button scroll', 'chiron'),
			"param_name" => "btn_link_scroll",
			"value" => "",
			"description" => esc_html__("Add link button scroll.", 'chiron'),   
		  	"dependency"  => array( 'element' => 'btnscroll', 'not_empty' => true, ),     
        )
    );   
	vc_add_param(
		'vc_row',
		array(
			"type" => "dropdown",
			"heading" => esc_html__('Setup Possition Button Scroll For Row', 'chiron'),
			"param_name" => "possition_btn",
			"value" => array(   
			                esc_html__('Center Right', 'chiron') => 'right',  
			                esc_html__('Center Bottom', 'chiron') => 'bottom',                                                                                
			              ),
			"description" => esc_html__("Select Possition Button for row.", 'chiron'),     
		  	"dependency"  => array( 'element' => 'btnscroll', 'not_empty' => true, ),      
        )
    );    

	// Add new Param in Column	
	vc_add_param('vc_column',array(
		  "type" => "dropdown",
		  "heading" => esc_html__('Animate Column', 'chiron'),
		  "param_name" => "animate",
		  "value" => array(   
							esc_html__('None', 'chiron') => 'none', 
							esc_html__('Move Top', 'chiron') => 'topmove',
							esc_html__('Move Bottom', 'chiron') => 'bottommove', 
							esc_html__('Move Left', 'chiron') => 'leftmove', 
							esc_html__('Move Right', 'chiron') => 'rightmove',  
						  ),
		  "description" => esc_html__("Select Animate , Default: None", 'chiron'),      
		) 
    );
	vc_add_param('vc_column',array(
		  "type" => "textfield",
		  "heading" => esc_html__('Animation Distance', 'chiron'),
		  "param_name" => "distance",
		  "value" => "",
		  "description" => esc_html__("Input distance show column. Example: 50, 60, etc", 'chiron'), 
		  "dependency"  => array( 'element' => 'animate', 'value' => array( 'topmove', 'bottommove', 'leftmove', 'rightmove' ) ),     
		) 
    );
    vc_add_param('vc_column',array(
		  "type" => "textfield",
		  "heading" => esc_html__('Animation Time', 'chiron'),
		  "param_name" => "time",
		  "value" => "",
		  "description" => esc_html__("Input time show column. Example: 0.8, 0.9, ...", 'chiron'),   
		  "dependency"  => array( 'element' => 'animate', 'value' => array('topmove', 'bottommove', 'leftmove', 'rightmove' ) ),   
		) 
    );  
    vc_add_param('vc_column',array(
		  "type" => "textfield",
		  "heading" => esc_html__('Animation Time After.', 'chiron'),
		  "param_name" => "after",
		  "value" => "",
		  "description" => esc_html__("Input time show column. Example: 0.1, 0.2 ...", 'chiron'),   
		  "dependency"  => array( 'element' => 'animate', 'value' => array('topmove', 'bottommove', 'leftmove', 'rightmove' ) ),   
		) 
    );  
}	
