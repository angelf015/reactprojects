<?php
//convert hex to rgb
if ( !function_exists ('alit_getbowtied_hex2rgb') ) {
	function alit_getbowtied_hex2rgb($hex) {
		$hex = str_replace("#", "", $hex);
		
		if(strlen($hex) == 3) {
			$r = hexdec(substr($hex,0,1).substr($hex,0,1));
			$g = hexdec(substr($hex,1,1).substr($hex,1,1));
			$b = hexdec(substr($hex,2,1).substr($hex,2,1));
		} else {
			$r = hexdec(substr($hex,0,2));
			$g = hexdec(substr($hex,2,2));
			$b = hexdec(substr($hex,4,2));
		}
		$rgb = array($r, $g, $b);
		return implode(",", $rgb); // returns the rgb values separated by commas
		//return $rgb; // returns an array with the rgb values
	}
}
if ( !function_exists ('alit_custom_styles') ) {
	function alit_custom_styles() {
		global $post;	
		
		ob_start();	
		?>
		
		<!-- ******************************************************************** -->
		<!-- * Theme Options Styles ********************************************* -->
		<!-- ******************************************************************** -->
			
		<style>

			/* check main color */ 
			<?php if ( alit_get_config('main_color') != "" ) : ?>

				/* seting border color main */
				.btn-theme
				{
					border-color: <?php echo esc_html( alit_get_config('main_color') ) ?>;
				}

				/* seting background main */
				.btn-theme
				{
					background: <?php echo esc_html( alit_get_config('main_color') ) ?>;
				}
				/* setting color*/
				.apus-breadscrumb .back-link:hover,
				.apus-footer .kc_title,
				.apus-breadscrumb .breadcrumb li,
				.text-theme,
				a:hover,a:focus
				{
					color: <?php echo esc_html( alit_get_config('main_color') ) ?>;
				}
			<?php endif; ?>

			/* Custom CSS */
			<?php if ( alit_get_config('custom_css') != "" ) : ?>
				<?php echo alit_get_config('custom_css') ?>
			<?php endif; ?>

		</style>

	<?php
		$content = ob_get_clean();
		$content = str_replace(array("\r\n", "\r"), "\n", $content);
		$lines = explode("\n", $content);
		$new_lines = array();
		foreach ($lines as $i => $line) {
			if (!empty($line)) {
				$new_lines[] = trim($line);
			}
		}
		
		echo implode($new_lines);
	}
}

?>
<?php add_action( 'wp_head', 'alit_custom_styles', 99 ); ?>