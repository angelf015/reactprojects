Please reference Theme Documentation for Demo Content installation.

See DOCS folder and open the index.html file in your browser. Reference the "Demo Content" section.