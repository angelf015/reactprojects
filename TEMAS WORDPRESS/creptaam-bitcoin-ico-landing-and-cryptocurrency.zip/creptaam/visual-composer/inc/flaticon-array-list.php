<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

$creptaam_flaticon_array = array(
	array('flaticon-001-bitcoin-20'=>'001-bitcoin-20'),
	array('flaticon-002-network'=>'002-network'),
	array('flaticon-003-bitcoin-19'=>'003-bitcoin-19'),
	array('flaticon-004-bitcoin-18'=>'004-bitcoin-18'),
	array('flaticon-005-padlock'=>'005-padlock'),
	array('flaticon-006-bitcoin-17'=>'006-bitcoin-17'),
	array('flaticon-007-bitcoin-16'=>'007-bitcoin-16'),
	array('flaticon-008-bitcoin-15'=>'008-bitcoin-15'),
	array('flaticon-009-gold-ingot'=>'009-gold-ingot'),
	array('flaticon-010-bitcoin-14'=>'010-bitcoin-14'),
	array('flaticon-011-bitcoin-13'=>'011-bitcoin-13'),
	array('flaticon-012-bitcoin-12'=>'012-bitcoin-12'),
	array('flaticon-013-bitcoin-11'=>'013-bitcoin-11'),
	array('flaticon-014-bitcoin-10'=>'014-bitcoin-10'),
	array('flaticon-015-invoice'=>'015-invoice'),
	array('flaticon-016-piggy-bank'=>'016-piggy-bank'),
	array('flaticon-017-placeholder'=>'017-placeholder'),
	array('flaticon-018-bitcoin-9'=>'018-bitcoin-9'),
	array('flaticon-019-bitcoin-8'=>'019-bitcoin-8'),
	array('flaticon-020-bitcoin-7'=>'020-bitcoin-7'),
	array('flaticon-021-bitcoin-6'=>'021-bitcoin-6'),
	array('flaticon-022-safebox'=>'022-safebox'),
	array('flaticon-023-bitcoin-5'=>'023-bitcoin-5'),
	array('flaticon-024-bitcoin-4'=>'024-bitcoin-4'),
	array('flaticon-025-pick'=>'025-pick'),
	array('flaticon-026-bitcoin-3'=>'026-bitcoin-3'),
	array('flaticon-027-bitcoin-2'=>'027-bitcoin-2'),
	array('flaticon-028-bank'=>'028-bank'),
	array('flaticon-029-bitcoin-1'=>'029-bitcoin-1'),
	array('flaticon-030-bitcoin'=>'030-bitcoin')
);