<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header();
?>

<!-- subheader begin -->
<div class="section padding-top-hero padding-bottom-big over-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-center-text-wrap text-center">
                <h1 class="parallax-fade-top-2"><strong>-</strong><?php esc_html_e(' latest news ','chiron'); ?><strong>-</strong><br><span><?php esc_html_e('journal','chiron'); ?></span></h1>
            </div>  
        </div>      
    </div>  
</div>  
<!-- subheader close -->

<!-- content begin -->
<div class="section">
    <div class="container-fluid">
        <div id="blog-grid">
            <?php
    			if ( have_posts() ) :

    				/* Start the Loop */
    				while ( have_posts() ) : the_post();

    					/*
    					 * Include the Post-Format-specific template for the content.
    					 * If you want to override this in a child theme, then include a file
    					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
    					 */
    					get_template_part( 'template-parts/post/content', get_post_format() );

    				endwhile;							

    			else :

    				get_template_part( 'template-parts/post/content', 'none' );

    			endif;
    		?>    

        </div>
    </div>
</div>

<?php if ($wp_query->max_num_pages > 1) { ?>
<div class="section padding-top-bottom-small">
    <div class="container">
        <div class="row">
            <div class="col-md-12 pagination-full">
                <div class="project-nav-wrap">
                    <div class="col-md-6 col-6 right-align"><?php previous_posts_link( '<div class="left-nav" data-scroll-reveal="enter left move 60px over 0.9s after 0.1s">'. esc_html__( 'new', 'chiron' ) .'<div class="text-on-hover">'. esc_html__( 'new entries', 'chiron' ) .'</div></div>' ); ?></div>
                    <div class="col-md-6 col-6 left-align"><?php next_posts_link( '<div class="right-nav" data-scroll-reveal="enter right move 60px over 0.9s after 0.1s">'. esc_html__( 'old', 'chiron' ) .'<div class="text-on-hover">'. esc_html__( 'older entries', 'chiron' ) .'</div></div>' ); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php if(chiron_get_option('clientlogo_switch')==true ){ ?>
<div class="section padding-top-bottom-small background-dark">
    <div class="container">
        <div class="row logo-section">
            <?php $logo = chiron_get_option( 'clients_logo', array() ); ?>
            <?php foreach ( $logo as $logos ) {
              $img   = wp_get_attachment_image_src($logos['logo_img'],'full');
              $img   = $img[0];  
            ?>                                  
                <div class="col-sm-6 col-md-4 col-xl-2">
                    <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                </div>                     
            <?php } ?>
        </div>      
    </div>  
</div>
<?php } ?>
<!-- content close -->

<?php get_footer();
