<?php

$atts  = array_merge( array(
	'image' => '',
	'text_style' => '',
	'title' => '',
	'subtitle' => '',
	'url' => '',
), $atts);

extract( $atts );

$img = wp_get_attachment_image_src($image, 'full');
$style = '';
if (isset($img[0]) && $img[0]) {
	$style = 'style="background-image:url('.esc_url($img[0]).');"';
}
?>
<div class="widget widget-banner text-style-<?php echo esc_attr($text_style); ?>" <?php echo trim($style); ?>>
	<div class="banner-body">
		<?php if ( $url ) { ?>
			<a href="<?php echo esc_url($url); ?>">
		<?php } ?>
			<?php if ( $title ) { ?>
				<h3 class="banner-title"><?php echo trim($title); ?></h3>
			<?php } ?>
			<?php if ( $subtitle ) { ?>
				<div class="banner-subtitle"><?php echo trim($subtitle); ?></div>
			<?php } ?>
		<?php if ( $url ) { ?>
			</a>
		<?php } ?>
	</div>
</div>
