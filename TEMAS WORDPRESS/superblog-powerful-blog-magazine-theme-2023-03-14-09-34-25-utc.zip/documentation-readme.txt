Read the documentation on how to set up and how to use the theme.

Online documentation: 
http://themestate.com/demo/superblog

THX