For theme documentation, please visit this link:

https://tommusrhodus.ticksy.com/articles/100001521/?print

Documentation is linked so that you're always viewing the most up to date version :)