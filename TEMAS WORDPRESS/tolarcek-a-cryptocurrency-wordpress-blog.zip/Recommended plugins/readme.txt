Plugins that made the theme complete are in this
directory. A short description is below.

Theme uses several plugins for full functionality, below is a short description with links for all of them:


1. essential-grid
   - this plugin is crucial as it adds galleries like seen in live demo. This is a premium plugin from Themepunch (just like Revolution Slider). It's an added value of $26.

2. revslider
   - another premium plugin from Themepunch that is used for great main Slideshows. It's an added value of $25.

3. premiumcoding-crypto-coins - CRYPTO PLUGIN
   - this is a plugin that you will need if you want the crypto widgets


4. instagram-feed
   - this plugin adds the instagram gallery just above the footer. Instructions on how to connect to instagram are available in the plugin itself.
     Plugin can be downloaded from Wordpress repository at: https://wordpress.org/plugins/instagram-feed/


5. shortcodes-ultimate
   - this plugin adds the shortcodes. Plugin is not neccessary but if you wish to use some nice typography effects like dropcap, quotes and columns, you will
     have to install it.
     Plugin can be downloaded from Wordpress repository at: https://wordpress.org/plugins/shortcodes-ultimate/ 


6. contact-form - CONTACT FORM
   - this is a plugin that you will need of you want to add the contact form. Plugin can be downloaded
     from Wordpress repository at: http://wordpress.org/plugins/contact-form-7/

7. Widgets Import:
   - if you also wish to import widgets from demo, you can use this plugin: https://wordpress.org/plugins/widget-importer-exporter/

8. recent-tweets-widget - TWITTER FEED
   - this is a plugin that you will need of you want to add the twitter feed. Plugin can be downloaded
     from Wordpress repository at: https://wordpress.org/plugins/recent-tweets-widget/

9. facebook-pagelike-widget - FACEBOOK FEED
   - this is a plugin that you will need of you want to add the facebook feed. Plugin can be downloaded
     from Wordpress repository at: https://wordpress.org/plugins/facebook-pagelike-widget/

10. wysija-newsletters.2.6.15 - NEWSLETTER PLUGIN
   - this is a plugin that you will need of you want to add the newsletter. Plugin can be downloaded
     from Wordpress repository at: https://wordpress.org/plugins/wysija-newsletters/



