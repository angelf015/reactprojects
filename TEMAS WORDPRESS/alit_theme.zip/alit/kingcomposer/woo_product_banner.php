<?php

$atts  = array_merge( array(
	'product_special' => '',
	'title' => '',
	'subtitle' => '',
	'price' => '',
	'description' => '',
	'button_text' => '',
	'image' => '',
	'layout_type' => '',
), $atts);
extract( $atts );

$product_special = alit_autocomplete_options_helper($product_special);
if (is_array($product_special) && isset($product_special[0])) {
	$product_special = $product_special[0];
}

if ($product_special) {
	global $product, $post;
	$product = wc_get_product( $product_special );
	$post = get_post($product->get_id());
	setup_postdata($post);

	$img = wp_get_attachment_image_src($image, 'full');
	?>
	<div class="widget widget-product-banner layout-<?php echo esc_attr($layout_type); ?>">
		<?php if ($layout_type == 1 || $layout_type == 2): ?>
			<div class="row no-margin">
				<div class="no-padding col-xs-12 col-md-6 <?php echo ($layout_type == 2 ? 'pull-right' : ''); ?>">
					<?php if (isset($img[0]) && $img[0]) { ?>
						<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>">
							<?php alit_display_image($img); ?>
						</a>
					<?php } ?>
				</div>
				<div class="no-padding col-md-6 col-xs-12">
					<div class="banner-body">
						<?php if ($subtitle) { ?>
							<div class="subtitle"><?php echo trim($subtitle); ?></div>
						<?php } ?>
						<?php if ($title) { ?>
							<h3><a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"><?php echo trim($title); ?></a></h3>
						<?php } ?>
						<?php if ($price) { ?>
							<div class="banner-price"><?php echo trim($price); ?></div>
						<?php } ?>
						<?php if ($description) { ?>
							<div class="banner-description"><?php echo trim($description); ?></div>
						<?php } ?>
						<?php if ($button_text) { ?>
							<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"><?php echo trim($button_text); ?></a>
						<?php } ?>
					</div>
				</div>
			</div>
		<?php elseif ($layout_type == 3): ?>
			<div class="banner-image">
				<?php if (isset($img[0]) && $img[0]) { ?>
					<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>">
						<?php alit_display_image($img); ?>
					</a>
				<?php } ?>
			</div>
			<div class="banner-content">
				<?php if ($title) { ?>
				<h3><a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"><?php echo trim($title); ?></a></h3>
				<?php } ?>
				<?php if ($price) { ?>
				<div class="banner-price"><?php echo trim($price); ?></div>
				<?php } ?>
			</div>
		<?php elseif ($layout_type == 4): ?>
			<div class="banner-image">
				<?php if (isset($img[0]) && $img[0]) { ?>
					<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>">
						<?php alit_display_image($img); ?>
					</a>
				<?php } ?>
			</div>
			<div class="banner-content">
				<?php if ($subtitle) { ?>
				<div class="subtitle"><?php echo trim($subtitle); ?></div>
				<?php } ?>
				<?php if ($title) { ?>
				<h3><a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"><?php echo trim($title); ?></a></h3>
				<?php } ?>
				
				<?php if ($description) { ?>
				<div class="banner-description"><?php echo trim($description); ?></div>
				<?php } ?>
				<div class="banner-actions">
					<?php if ($price) { ?>
					<div class="banner-price"><?php echo trim($price); ?></div>
					<?php } ?>
					<?php if ($button_text) { ?>
					<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>" class="pull-right"><?php echo trim($button_text); ?></a>
					<?php } ?>
				</div>
			</div>
		<?php else: ?>
			<div class="row no-margin">
				<div class="no-padding col-sm-6">
					<?php if ($title) { ?>
					<h3><a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"><?php echo trim($title); ?></a></h3>
					<?php } ?>
					<?php if ($price) { ?>
					<div class="banner-price"><?php echo trim($price); ?></div>
					<?php } ?>
				</div>
				<div class="no-padding col-sm-6">
					<?php if (isset($img[0]) && $img[0]) { ?>
						<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>">
							<?php alit_display_image($img); ?>
						</a>
					<?php } ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
	<?php
	wp_reset_postdata();
}
