<div id="apus-mobile-menu" class="apus-offcanvas hidden-lg hidden-md"> 
    <div class="apus-offcanvas-body">
        <div class="offcanvas-head bg-primary">
            <button type="button" class="btn btn-toggle-canvas btn-danger" data-toggle="offcanvas">
                <i class="fa fa-close"></i> 
            </button>
            <strong><?php esc_html_e( 'MENU', 'alit' ); ?></strong>
        </div>
        <?php get_template_part( 'page-templates/parts/productsearchform' ); ?>

        <?php
        $header = apply_filters( 'alit_get_header_layout', alit_get_config('header_type') );
        if ( $header == 'v2' ) {
        ?>
            <nav class="navbar navbar-offcanvas navbar-static" role="navigation">
                <?php
                    $args = array(
                        'theme_location' => 'topmenu',
                        'container_class' => 'navbar-collapse navbar-offcanvas-collapse',
                        'menu_class' => 'nav navbar-nav',
                        'fallback_cb' => '',
                        'menu_id' => 'main-mobile-topmenu',
                        'walker' => new Alit_Mobile_Menu()
                    );
                    wp_nav_menu($args);
                ?>
            </nav>
        <?php } else { ?>
            <nav class="navbar navbar-offcanvas navbar-static" role="navigation">
                <?php
                    $args = array(
                        'theme_location' => 'primary',
                        'container_class' => 'navbar-collapse navbar-offcanvas-collapse',
                        'menu_class' => 'nav navbar-nav',
                        'fallback_cb' => '',
                        'menu_id' => 'main-mobile-menu',
                        'walker' => new Alit_Mobile_Menu()
                    );
                    wp_nav_menu($args);
                ?>
            </nav>
        <?php } ?>

        <?php if ( has_nav_menu( 'my-account' ) ) { ?>
            <h3 class="setting"><i class="fa fa-cog" aria-hidden="true"></i> <?php esc_html_e( 'Setting', 'alit' ); ?></h3>
                <?php
                    $args = array(
                        'theme_location'  => 'my-account',
                        'container_class' => '',
                        'menu_class'      => 'menu-topbar'
                    );
                    wp_nav_menu($args);
                ?>
        <?php } ?>
    </div>
</div>
