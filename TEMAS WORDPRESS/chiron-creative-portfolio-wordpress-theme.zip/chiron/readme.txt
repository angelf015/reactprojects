=== Chiron ===
Contributors: the OceanThemes team
Tags: one-column, flexible-header, accessibility-ready, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, rtl-language-support, sticky-post, threaded-comments, translation-ready
Requires at least: 4.9.6
Tested up to: WordPress 5.0
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Chiron is a complete and versatile WordPress theme that is perfect for creative portfolios – from bloggers and freelancers to video production and commercial stores. Whether you want to present a collection of work, inspiration, products or services, this portfolio template has every detail covered.

== Changelog ==

= 1.0 =
* Released: February 10, 2019

Initial release

== Resources ==
