03/18/2020: Updated to version 1.8.3
	- Changed links install require plugins
	- Updated WooCommerce version 4.0.x

07/11/2019: Updated version 1.8.2
	- Updated WooCommerce 3.6.4

01/16/2019: Updated version 1.8.1
	- Updated WooCommerce 3.5.3
	
08/08/2018: Updated version 1.8
	- Updated WooCommerce 3.4
	
03/14/2018: Updated to version 1.7
	- Updated WooCommerce 3.3
		
07/27/2016: Updated to version 1.6
	- Updated the WooCommerce template files for 2.6.1 version
	- Updated css for new WooCommerce 2.6.1
	-------------------------------
	Updated details:
		- Updated "less/global.less"
		- Updated "less/layouts.less"
		- Updated "less/responsive.less"
		- Updated "woocommerce/archive-product.php"
		- Updated "woocommerce/content-product.php"
		- Updated "theme-config.php"
		
		- Added "woocommerce/content-product_cat.php"
		
		- Removed "woocommerce/myaccount/form-login.php"
		- Removed "woocommerce/myaccount/form-lost-password.php"
		- Removed "woocommerce/myaccount/my-address.php"
		- Removed "woocommerce/myaccount/view-order.php"
	-------------------------------

04/26/2016: Updated to version 1.5.5
	- Updated Visual Composer plugin to the 4.11.2.1 version
	-------------------------------
	
03/21/2016: Updated to version 1.5.4
	- Updated template files for new WooCommerce 2.5
	-------------------------------
	Updated details:
	- updated woocommerce/cart/mini-cart.php
	- updated woocommerce/content-product.php
	- updated woocommerce/myaccount/my-orders.php
	- updated woocommerce/single-product/add-to-cart/variable.php
	
	- removed woocommerce/single-product/review.php
	- removed woocommerce/single-product/sale-flash.php

	-------------------------------
	
12/11/2015: Updated to version 1.5.3
	- Updated template files for new WooCommerce 2.4
	- Fixed missing fields in Theme Options panel
	- Update the TGM-Plugin-Activation to version 2.5.2
	-------------------------------
	Updated details:
	- Updated woocommerce/single-product/price.php
	- Updated theme-config.php
	- Updated "class-tgm-plugin-activation.php"

		-------------------------------
08/22/2015: Updated to version 1.5.2
	- Updated template files for new WooCommerce 2.4
	- Fixed displaying of cart page
	-------------------------------
	Updated details:
	- removed woocommerce/order/order-details.php
	- removed woocommerce/single-product/tabs/tabs.php
	- updated woocommerce/content-product.php (only change version to 2.4.0)
	- updated woocommerce/single-product/add-to-cart/variable.php
	- updated woocommerce/cart/cart.php
	- updated less/global.less
	-------------------------------
	
06/25/2015: Updated to version 1.5.1
	- Fix the issue on displaying of shipping methods
	-------------------------------
	Updated details:
		- Updated "less/global.less"
			added this css code at bottom of file:
			.woocommerce ul#shipping_method li {
				text-indent: 0;
			}
	-------------------------------

06/25/2015: Updated to version 1.5
	- prettyPhoto XSS fix
	- Update WooCommerce template file
	- Added add_theme_support( 'title-tag' ); into the "functions.php" file
	- Update the TGM-Plugin-Activation plugin to version 2.4.2
	- Fix portfolio javascript
	- Fix SSL for favicon, logo, fonts
	- Updated plugin "RoadThemes Helper" (delete & reinstall to update)
	- Updated theme options
	-------------------------------
	Updated details:
		- Updated "class-tgm-plugin-activation.php"
		- Updated "woocommerce/myaccount/my-orders.php"
		- Updated "woocommerce/content-product.php"
		- Updated "woocommerce/cart/mini-cart.php"
		- Updated "functions.php"
		- Updated "header.php"
		- Updated "js/theme.js"
		- Updated "header-first.php;header-second.php;header-third.php;header-fourth.php;header-fifth.php;header-sixth.php"
		- Updated "plugins/roadthemes-helper.zip"
		- Updated "less/variables.less"
		- Updated "less/global.less"
		- Updated "theme-config.php"
	-------------------------------
	
04/23/2015: Updated to version 1.4
	- Update the TGM-Plugin-Activation to version 2.4.1
	- Update the WooCommerce cart template to version 2.3.8
	
	-------------------------------
	Updated details:
		- Updated "class-tgm-plugin-activation.php"
		- Updated "woocommerce/cart/cart.php"
		- Updated "functions.php"

	-------------------------------

03/16/2015: Updated to version 1.3
	- Fixed the price on variable product
	- Fixed the CSS on mobile
	
	-------------------------------
	Updated details:
		- Updated "less/global.less" & "less/responsive.less"
		- Updated "functions.php"		

02/14/2015: Updated to version 1.2
	- Update theme to make it works with WooCommerce 2.3.x
	- Fixed some CSS code to make theme display better
	
	-------------------------------
	Updated details:
		- Add "include" folder and remove "widgets" folder
		- Updated "less/global.less" & "less/layout.less"
		- Updated "page-templates/full-width.php"
		- Updated plugin: roadthemes-helper
		- Updated all "header-x.php" files
		- Updated "functions.php"
		- Updated "theme-config.php"
		- Added "wpml-config.xml"
		- Updated "woocommerce" folder:
			cart/cart.php
			checkout/form-checkout.php
			global/breadcrumb.php
			myaccount/my-orders.php
			myaccount/form-lost-password.php
			order/order-details.php
			single-product/rating.php
			single-product/add-to-cart/variable.php
			content-product.php
			single-product-reviews.php
			
01/17/2015: Updated to version 1.0.1
	-	Update theme files to make register form works on latest version of WooCommerce
	-	To update current theme without re-installing, replace all files in "woocommerce/myaccount" folder with new files from updated theme "woocommerce/myaccount".
	
		
11/16/2014: Released version 1.0
	-	You need read instruction in documentation folder
	-	Download PSD source : http://demo4plazathemes.com/19/psd/ma_rubbez_psd_source_383757.zip
	






	

