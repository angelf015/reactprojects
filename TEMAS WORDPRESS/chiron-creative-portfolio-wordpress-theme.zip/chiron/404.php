<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header();
?>

<!-- subheader begin -->
<div class="section padding-top-hero padding-bottom-big over-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-center-text-wrap text-center">
                    <h1><?php esc_html_e('Oops! That page can&rsquo;t be found.','chiron'); ?></h1>
                    <h1><span><?php esc_html_e( '404', 'chiron' ); ?></span></h1>
            </div>  
        </div>      
    </div>  
</div> 
<!-- subheader close -->

<!-- content begin -->
<div class="section padding-top-bottom">
    <div class="container">      	
        <div class="col-md-8">
            <div class="post-wrapper">
				<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'chiron' ); ?></p>

				<?php get_search_form(); ?>

			</div><!-- .page-content -->
        </div>       
    </div>
</div>
<!-- content close -->

<?php get_footer();
