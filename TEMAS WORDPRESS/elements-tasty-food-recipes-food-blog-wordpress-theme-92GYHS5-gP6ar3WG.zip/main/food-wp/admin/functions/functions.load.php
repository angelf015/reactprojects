<?php
/**
 * Functions Load
 *
 * @package     WordPress
 * @subpackage  SMOF
 * @since       1.4.0
 * @author      Syamil MJ
 */
include( get_template_directory() . '/admin/functions/functions.php' );
include( get_template_directory() . '/admin/functions/functions.filters.php' );
include( get_template_directory() . '/admin/functions/functions.interface.php' );
include( get_template_directory() . '/admin/functions/functions.options.php' );
include( get_template_directory() . '/admin/functions/functions.admin.php' );