<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header(); ?>

<!-- subheader begin -->
<div class="section padding-top-hero padding-bottom-big over-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-center-text-wrap text-center">
                <?php while ( have_posts() ) : the_post(); ?>
                <h1 class="parallax-fade-top-2"><strong>-</strong> <?php esc_html_e('by ','chiron'); ?> <?php the_author(); ?> <strong>-</strong><br><span><?php the_title(); ?></span></h1>
                <?php endwhile; ?>
            </div>
        </div>  
    </div>`
</div>
<!-- subheader close -->

<!-- content begin -->
<div class="section padding-bottom-big">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="blog-list">
                	<?php while ( have_posts() ) : the_post(); ?>

                		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	
                            <div class="section drop-shadow rounded pt-4">
                                <div class="post-box background-white over-hide">						
            						<div class="entry-content padding-in">
            							<?php
            								the_content();

            								wp_link_pages( array(
            									'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'chiron' ),
            									'after'  => '</div>',
            								) );
            							?>
            						</div><!-- .entry-content -->
                                </div>
                            </div>
    					</article><!-- #post-## -->
    						
    					<?php 
    						// If comments are open or we have at least one comment, load up the comment template.
    						if ( comments_open() || get_comments_number() ) :
    							comments_template();
    						endif;
    					?>
    				<?php endwhile; // End of the loop. ?>      
                </div>          	                                        
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0">   
                <div class="sidebar-box background-white drop-shadow rounded">                
                    <?php get_sidebar(); ?>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- content close -->

<?php get_footer();
