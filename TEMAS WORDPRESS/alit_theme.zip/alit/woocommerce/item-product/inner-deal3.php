<?php 
global $product;
$time_sale = get_post_meta( $product->get_id(), '_sale_price_dates_to', true );
?>
<div class="product-block product-deal product-deal3" data-product-id="<?php echo esc_attr($product->get_id()); ?>">
    <div class="row">
        <div class="col-sm-4">
            <figure class="image">
                <?php alit_product_get_images('shop_single'); ?>
            </figure>
        </div>
        <div class="col-sm-4">
            <div class="caption">
                <div class="time">
                    <?php if ( $time_sale ): ?>
                        <span class="time-label"><?php echo esc_html__('Limited Deals', 'alit'); ?></span>
                        <div class="apus-countdown clearfix" data-time="timmer"
                             data-date="<?php echo date('m', $time_sale).'-'.date('d', $time_sale).'-'.date('Y', $time_sale).'-'. date('H', $time_sale) . '-' . date('i', $time_sale) . '-' .  date('s', $time_sale) ; ?>">
                        </div>
                    <?php endif; ?> 
                </div>
                <div class="meta">
                    <h3 class="name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <a href="<?php the_permalink(); ?>"><?php esc_html_e( 'See More Detail', 'alit' ); ?></a>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="deals-price">
                <?php
                    /**
                    * woocommerce_after_shop_loop_item_title hook
                    *
                    * @hooked woocommerce_template_loop_rating - 5
                    * @hooked woocommerce_template_loop_price - 10
                    */
                    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
                    do_action( 'woocommerce_after_shop_loop_item_title');

                ?>
            </div>
        </div>
    </div>

    <div class="sale-off">
        <?php
            $regular_price = $product->get_regular_price();
            $sale_price = $product->get_sale_price();
            
            $percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
            echo sprintf(__('%s OFF', 'alit'), $percentage.'%' );
        ?>
    </div>
</div>
