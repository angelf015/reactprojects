<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.2
 */

?>
	
    <!-- footer close -->
    <div class="section footer padding-top-big background-image-cover" style="background-image: url(<?php echo esc_url(chiron_get_option('bg_ft')); ?>);">	
		<div class="container">
			<div class="row">
				<div class="col-md-12">	
					<img src="<?php echo esc_url(chiron_get_option('logo_ft')); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"/>
				</div>	
				<div class="col-md-12 my-4">
					<ul class="footer-social">
						<?php $socials = chiron_get_option( 'footer_socials', array() ); ?>
				        <?php foreach ( $socials as $social ) { ?>                                  
				            <li><a href="<?php echo esc_url($social['social_link']); ?>"><?php echo esc_attr($social['social_name']); ?></a></li>                     
				        <?php } ?>
					</ul>	
				</div>	
				<div class="col-md-12 mt-5">
					<div class="footer-line"></div>	
				</div>	
				<div class="col-md-12 rights my-3">
					<p><?php echo wp_specialchars_decode(chiron_get_option('copyright')) ?></p>
				</div>	
			</div>
		</div>	
	</div>
</main>
<?php wp_footer(); ?>

</body>
</html>
