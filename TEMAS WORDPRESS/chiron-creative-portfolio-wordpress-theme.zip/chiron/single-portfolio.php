<?php
/**
 * The template for displaying all single porfolio
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header(); ?>

	<?php if (have_posts()){ ?>
		<?php while (have_posts()) : the_post()?>
			<?php the_content(); ?>
		<?php endwhile; ?>
	<?php }else {
		_e('Page Canvas For Page Builder', 'chiron'); 
	}?>

<div class="section padding-bottom">					
	<div class="container">
		<div class="row">
			<div class="col-md-12 mt-5">	
				<div class="project-nav-wrap row">
					<div class="col-md-6 col-6 right-align">
						<?php echo previous_post_link('%link', __('<div class="left-nav" data-scroll-reveal="enter left move 60px over 0.9s after 0.1s">prev<div class="text-on-hover">%title</div></div>', 'chiron'), $post->max_num_pages); ?>
							
					</div>
					<div class="col-md-6 col-6 left-align">
						<?php echo next_post_link('%link', __('<div class="right-nav" data-scroll-reveal="enter left move 60px over 0.9s after 0.1s">next<div class="text-on-hover">%title</div></div>', 'chiron'), $post->max_num_pages); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php if(chiron_get_option('clients_logo')!=''){ ?>
<div class="section padding-top-bottom-small background-dark">
    <div class="container">
        <div class="row logo-section">
            <?php $logo = chiron_get_option( 'clients_logo', array() ); ?>
            <?php
              $i=0;
              foreach ( $logo as $logos ) {
              $img   = wp_get_attachment_image_src($logos['logo_img'],'full');
              $img   = $img[0];  
              $i++;
            ?>                                  
                <div class="col-sm-6 col-md-4 col-xl-2 <?php if($i==2){ echo 'mt-4 mt-sm-0';}elseif($i==3){ echo 'mt-4 mt-md-0';}elseif($i>3){echo 'mt-4 mt-xl-0';} ?>">
                    <img src="<?php echo esc_url($img); ?>" alt="">
                </div>                     
            <?php } ?>
        </div>      
    </div>  
</div>
<?php } ?>
<?php get_footer(); ?>	
