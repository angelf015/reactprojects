<header id="apus-header" class="site-header header-sidebar-left header-v2 hidden-sm hidden-xs " role="banner">
    <span class="show-header btn btn-primary btn-sm" title="<?php echo esc_html__('show Menu','alit'); ?>"> <i class="fa fa-hand-o-left" aria-hidden="true"></i></span>
    <div class="header-main clearfix">
        <div class="header-inner">
            <!-- LOGO -->
            <div class="logo-in-theme">
                <?php get_template_part( 'page-templates/parts/logo-icon-2' ); ?>
            </div>

            <!-- CART -->
            <?php if ( defined('ALIT_WOOCOMMERCE_ACTIVED') && ALIT_WOOCOMMERCE_ACTIVED ): ?>
                <div class="top-cart top-cart-full hidden-xs">
                    <?php get_template_part( 'woocommerce/cart/mini-cart-button2' ); ?>
                </div>
            <?php endif; ?>

            <!-- MAIN MENU -->
            <?php if ( has_nav_menu( 'primary' ) ) : ?>
                <nav 
                 data-duration="400" class="hidden-xs hidden-sm apus-megamenu slide animate navbar" role="navigation">
                <?php   $args = array(
                        'theme_location' => 'primary',
                        'container_class' => 'collapse navbar-collapse',
                        'menu_class' => 'nav navbar-nav megamenu main-menu-v1',
                        'fallback_cb' => '',
                        'menu_id' => 'primary-menu',
                        'walker' => new Alit_Nav_Menu()
                    );
                    wp_nav_menu($args);
                ?>
                </nav>
            <?php endif; ?>

            <!-- SOCIAL -->
            <?php if ( is_active_sidebar( 'social-header' ) ) { ?>
                <div class="social-header">
                    <?php dynamic_sidebar( 'social-header' ); ?>
                </div>
            <?php } ?>
        </div>
    </div>
</header>
<div class="full-shopping-cart">
    <button class="close-shopping-cart btn btn-danger">
        <i class="fa fa-close"></i>
    </button>
    <div class="widget_shopping_cart_content">
        <?php woocommerce_mini_cart(); ?>
    </div>
</div>