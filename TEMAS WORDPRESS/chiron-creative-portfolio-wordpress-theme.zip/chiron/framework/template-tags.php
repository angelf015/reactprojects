<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 */


if ( ! function_exists( 'chiron_entry_meta' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function chiron_entry_meta() {

$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
  if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
    $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><!--<time class="updated" datetime="%3$s">%4$s</time>-->';
  }

  $time_string = sprintf( $time_string,
    esc_attr( get_the_date( 'c' ) ),
    esc_html( get_the_date() ),
    esc_attr( get_the_modified_date( 'c' ) ),
    esc_html( get_the_modified_date() )
  );

  $posted_on = sprintf(
    esc_html_x( '%s', 'post date', 'chiron' ),
    //'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
        $time_string . ''
  );

    echo '' . $posted_on . ''; // WPCS: XSS OK.

}
endif;

//pagination
if ( ! function_exists( 'chiron_pagination' ) ) :
function chiron_pagination($prev = '<i class="fa fa-long-arrow-left" aria-hidden="true"></i>', $next = '<i class="fa fa-long-arrow-right" aria-hidden="true"></i>', $pages='') {
    global $wp_query, $wp_rewrite;
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
    if($pages==''){
        global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
    }
    $pagination = array(
		'base' 			=> str_replace( 999999999, '%#%', get_pagenum_link( 999999999 ) ),
		'format' 		=> '',
		'current' 		=> max( 1, get_query_var('paged') ),
		'total' 		=> $pages,
		'prev_text' => $prev,
        'next_text' => $next,		
        'type'			=> 'list',
		'end_size'		=> 3,
		'mid_size'		=> 3
    );
    $return =  paginate_links( $pagination );
	echo str_replace( "<ul class='page-numbers'>", "<ul class='blog-pagination'>", $return );
}
endif;

if ( ! function_exists( 'chiron_custom_wp_admin_style' ) ) :
function chiron_custom_wp_admin_style() {

        wp_register_style( 'chiron_custom_wp_admin_css', get_template_directory_uri() . '/assets/admin/admin-style.css', false, '1.0.0' );
        wp_enqueue_style( 'chiron_custom_wp_admin_css' );

        wp_enqueue_script( 'chiron-backend-js', get_template_directory_uri()."/assets/admin/admin-script.js", array( 'jquery' ), '1.0.0', true );
        wp_enqueue_script( 'chiron-backend-js' );
}
add_action( 'admin_enqueue_scripts', 'chiron_custom_wp_admin_style' );
endif;

if ( ! function_exists( 'chiron_search_form' ) ) :
/* Custom form search */
function chiron_search_form( $form ) {
    $form = '<form class="subscribe-box" role="search" method="get" action="' . esc_url(home_url( '/' )) . '" >  
        <input type="search" id="search" class="search-query form-control" value="' . get_search_query() . '" name="s" placeholder="'.__('type here here&hellip;', 'chiron').'" />
        
        <button class="btn btn-primary subscribe-1" type="search" data-lang="en"><span>search</span></button>
    </form>';
    return $form;
}
add_filter( 'get_search_form', 'chiron_search_form' );
endif;

/* Custom comment List: */
function chiron_theme_comment($comment, $args, $depth) {    
   $GLOBALS['comment'] = $comment;
?>
  <div class="section">
    <?php echo get_avatar($comment,$size='40',$default='http://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536' ); ?>
    <h6><?php printf('%s', get_comment_author()) ?> <small><?php comment_date('d M, Y'); ?> <?php esc_html_e('at','chiron'); ?> <?php the_time(); ?></small></h6>
    <?php if ($comment->comment_approved == '0'){ ?>
     <p><em><?php esc_html_e('Your comment is awaiting moderation.','chiron') ?></em></p>
    <?php }else{ ?>
      <?php comment_text() ?>
    <?php } ?>		
    <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
  </div>

  <div class="separator-wrap pt-4 pb-4">  
    <span class="separator"><span class="separator-line dashed"></span></span>
  </div>
<?php
}
if ( ! function_exists( 'chiron_excerpt_length' ) ) :
/**** Change length of the excerpt ****/
function chiron_excerpt_length() {
      global $chiron_option;
      if(chiron_get_option('blog_excerpt')!=''){
        $limit = chiron_get_option('blog_excerpt');
      }else{
        $limit = 15;
      }  
      $excerpt = explode(' ', get_the_excerpt(), $limit);

      if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).'...';
      } else {
        $excerpt = implode(" ",$excerpt);
      } 
      $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
      return $excerpt;
}
endif;
if ( ! function_exists( 'chiron_excerpt' ) ) :
/** Excerpt Section Blog Post **/
function chiron_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}
endif;

if ( ! function_exists( 'chiron_tag_cloud_widget' ) ) :
/**custom function tag widgets**/
function chiron_tag_cloud_widget($args) {
    $args['number'] = 0; //adding a 0 will display all tags
    $args['largest'] = 13; //largest tag
    $args['smallest'] = 13; //smallest tag
    $args['unit'] = 'px'; //tag font unit
    $args['format'] = 'list'; //ul with a class of wp-tag-cloud
    $args['exclude'] = ''; //exclude tags by ID
    return $args;
}
add_filter( 'widget_tag_cloud_args', 'chiron_tag_cloud_widget' );
endif;