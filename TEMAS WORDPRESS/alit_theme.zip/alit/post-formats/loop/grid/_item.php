<?php
    $thumbsize = isset($thumbsize) ? $thumbsize : alit_get_blog_thumbsize();
    $nb_word = isset($nb_word) ? $nb_word : 15;

    $categories = get_the_category();
    
?>

<article <?php post_class('post post-grid'); ?>>
    <?php
    $thumb = alit_display_post_thumb($thumbsize);
    echo trim($thumb);
    ?>
    <div class="entry-content <?php echo !empty($thumb) ? '' : 'no-thumb'; ?>">
        <div class="entry-meta">
            <div class="info">
                <?php
                if ( ! empty( $categories ) ) {
                ?>
                    <span class="categories">
                <?php
                    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                ?>
                    </span>
                <?php
                    }
                ?>
                -
                <span class="date"><?php the_time( 'M d , Y' ); ?>  </span>
            </div>
            <?php if (get_the_title()) { ?>
                <h4 class="entry-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h4>
            <?php } ?>
        </div>
        <div class="info-bottom">
            <?php if (! has_excerpt()) { ?>
                <div class="entry-description"><?php echo alit_substring( get_the_content(), $nb_word, '...' ); ?></div>
            <?php } else { ?>
                <div class="entry-description"><?php echo alit_substring( get_the_excerpt(), $nb_word, '...' ); ?></div>
            <?php } ?>

            <div class="meta">
                <!-- display like and comment -->
                <?php
                    printf( '<span class="post-author"><a href="%1$s">%2$s</a></span>',
                        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                        get_the_author()
                    );
                ?>
                <span class="post-comment">
                    <?php
                    printf( _nx( '1 Comment', '%1$s Comments', get_comments_number(), 'comments', 'alit' ), number_format_i18n( get_comments_number() ) );
                    ?>
                </span>
            </div>
        </div>
    </div>
</article>