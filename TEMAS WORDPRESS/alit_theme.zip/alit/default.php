<header id="apus-header" class="site-header header-default hidden-sm hidden-xs " role="banner">
    <div class="<?php echo (alit_get_config('keep_header') ? 'main-sticky-header-wrapper' : ''); ?>">
        <div class="header-main clearfix <?php echo (alit_get_config('keep_header') ? 'main-sticky-header' : ''); ?>">
            <div class="container">
                <div class="header-inner">
                        <div class="row">
                            <div class="col-md-5 p-static">
                                <?php if ( has_nav_menu( 'primary' ) ) : ?>
                                    <div class="main-menu  pull-left">
                                        <nav 
                                         data-duration="400" class="hidden-xs hidden-sm apus-megamenu slide animate navbar" role="navigation">
                                        <?php   $args = array(
                                                'theme_location' => 'primary',
                                                'container_class' => 'collapse navbar-collapse',
                                                'menu_class' => 'nav navbar-nav megamenu main-menu-v1',
                                                'fallback_cb' => '',
                                                'menu_id' => 'primary-menu',
                                                'walker' => new Alit_Nav_Menu()
                                            );
                                            wp_nav_menu($args);
                                        ?>
                                        </nav>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- LOGO -->
                            <div class="col-md-2">
                                <div class="logo-in-theme">
                                    <?php get_template_part( 'page-templates/parts/logo' ); ?>
                                </div>
                            </div>

                            <div class="col-md-5 p-static">
                                <div class="heading-right pull-right hidden-sm hidden-xs">
                                    <div class="pull-right  header-setting">

                                        <!-- user info --> 
                                        <div class="pull-right dropdown my-account">
                                            <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" role="button" aria-haspopup="true" data-delay="0" href="#" title="<?php esc_html_e('My Account', 'alit'); ?>">
                                                <img  src="<?php echo esc_url_raw( get_template_directory_uri().'/images/account-icon.png'); ?>" alt="">
                                            </a>
                                            <div class="dropdown-menu">
                                                <?php if ( has_nav_menu( 'topmenu' ) ): ?>
                                                    <nav class="apus-topmenu" role="navigation">
                                                        <?php
                                                            $args = array(
                                                                'theme_location'  => 'topmenu',
                                                                'menu_class'      => 'apus-menu-top',
                                                                'fallback_cb'     => '',
                                                                'menu_id'         => 'topmenu'
                                                            );
                                                            wp_nav_menu($args);
                                                        ?>
                                                    </nav>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <?php if ( defined('ALIT_WOOCOMMERCE_ACTIVED') && ALIT_WOOCOMMERCE_ACTIVED ): ?>
                                            <div class="pull-right">
                                                <div class="top-cart hidden-xs">
                                                    <?php get_template_part( 'woocommerce/cart/mini-cart-button' ); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <div class="pull-right">
                                            <div class="header-setting">
                                                <?php get_template_part( 'page-templates/parts/productsearchform' ); ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            
        </div>
    </div>
</header>