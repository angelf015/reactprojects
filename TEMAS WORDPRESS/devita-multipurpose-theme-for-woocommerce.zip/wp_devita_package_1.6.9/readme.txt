03/15/2021: Updated version 1.6.9
	- Updated WooCommerce version 5.1.x
	- Updated YITH WooCommerce Zoom Magnifier version 1.3.23
	
08/18/2020: Updated version 1.6.8
	- Updated theme compatible with WordPress 5.5

04/02/2020: Updated version 1.6.7
	- Updated Roadthemes-helper plugin
	
02/26/2020: Updated version 1.6.6
	- Updated WooCommerce 3.9.2
	- Changed links install require plugins

07/29/2019: Updated version 1.6.5
	- Updated plugin and fixed PHP version
	
06/03/2019: Updated version 1.6.4
	- Updated WooCommerce 3.6.4
	
03/27/2019: Updated version 1.6.3
	- Updated WooCommerce 3.5.5

12/28/2018: Updated version 1.6.2
	- Updated WooCommerce 3.5.2
	
10/26/2018: Updated version 1.6.1
	- Updated WooCommerce 3.5.0

08/09/2018: Updated 1.6
	- Updated new home page: Housewares, Underwear
	
07/31/2018: Updated 1.5
	- Updated new home page: #Kid toys, #Cosmetic

07/23/2018: Updated 1.4
	- Updated new home page: #organic, #petmarket

07/19/2018: Updated 1.2 to 1.3
	- Updated new home page: #furniture, #auto part

07/11/2018: Updated 1.1 to 1.2
	- Fixed the box layout

06/30/2018: Updated 1.0 to 1.1
	- Fixed error import data demo (road_importdada/importer.php)
	- Fixed background submenu home game