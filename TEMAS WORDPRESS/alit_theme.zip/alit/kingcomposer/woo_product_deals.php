<?php

$atts  = array_merge( array(
	'product_special' => '',
	'layout_type' => 'deal1'
), $atts);
extract( $atts );

$product_special = alit_autocomplete_options_helper($product_special);
if (is_array($product_special) && isset($product_special[0])) {
	$product_special = $product_special[0];
}
if ( $product_special ):
	
	global $product, $post;
	$product = wc_get_product( $product_special );
	$post = get_post($product->get_id());
	setup_postdata($post);
?>
	<div class="widget widget-product-deals">
		<?php wc_get_template_part( 'item-product/inner-'.$layout_type ); ?>
	</div>
	<?php wp_reset_postdata(); ?>
<?php
endif;