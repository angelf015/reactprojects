<?php
/**
 * chiron theme customizer
 *
 * @package chiron
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Chiron_Customize {
	/**
	 * Customize settings
	 *
	 * @var array
	 */
	protected $config = array();

	/**
	 * The class constructor
	 *
	 * @param array $config
	 */
	public function __construct( $config ) {
		$this->config = $config;

		if ( ! class_exists( 'Kirki' ) ) {
			return;
		}

		$this->register();
	}

	/**
	 * Register settings
	 */
	public function register() {
		/**
		 * Add the theme configuration
		 */
		if ( ! empty( $this->config['theme'] ) ) {
			Kirki::add_config(
				$this->config['theme'], array(
					'capability'  => 'edit_theme_options',
					'option_type' => 'theme_mod',
				)
			);
		}

		/**
		 * Add panels
		 */
		if ( ! empty( $this->config['panels'] ) ) {
			foreach ( $this->config['panels'] as $panel => $settings ) {
				Kirki::add_panel( $panel, $settings );
			}
		}

		/**
		 * Add sections
		 */
		if ( ! empty( $this->config['sections'] ) ) {
			foreach ( $this->config['sections'] as $section => $settings ) {
				Kirki::add_section( $section, $settings );
			}
		}

		/**
		 * Add fields
		 */
		if ( ! empty( $this->config['theme'] ) && ! empty( $this->config['fields'] ) ) {
			foreach ( $this->config['fields'] as $name => $settings ) {
				if ( ! isset( $settings['settings'] ) ) {
					$settings['settings'] = $name;
				}

				Kirki::add_field( $this->config['theme'], $settings );
			}
		}
	}

	/**
	 * Get config ID
	 *
	 * @return string
	 */
	public function get_theme() {
		return $this->config['theme'];
	}

	/**
	 * Get customize setting value
	 *
	 * @param string $name
	 *
	 * @return bool|string
	 */
	public function get_option( $name ) {
		if ( ! isset( $this->config['fields'][$name] ) ) {
			return false;
		}

		$default = isset( $this->config['fields'][$name]['default'] ) ? $this->config['fields'][$name]['default'] : false;

		return get_theme_mod( $name, $default );
	}
}

/**
 * This is a short hand function for getting setting value from customizer
 *
 * @param string $name
 *
 * @return bool|string
 */
function chiron_get_option( $name ) {
	global $chiron_customize;

	if ( empty( $chiron_customize ) ) {
		return false;
	}

	if ( class_exists( 'Kirki' ) ) {
		$value = Kirki::get_option( $chiron_customize->get_theme(), $name );
	} else {
		$value = $chiron_customize->get_option( $name );
	}

	return apply_filters( 'chiron_get_option', $value, $name );
}

/**
 * Move some default sections to `general` panel that registered by theme
 *
 * @param object $wp_customize
 */
function chiron_customize_modify( $wp_customize ) {
	$wp_customize->get_section( 'title_tagline' )->panel     = 'general';
	$wp_customize->get_section( 'static_front_page' )->panel = 'general';
}
add_action( 'customize_register', 'chiron_customize_modify' );

/**
 * Customizer configuration
 */
$chiron_customize = new Chiron_Customize(
	array(
		'theme'    => 'chiron',

		'panels'   => array(
			'general' => array(
				'priority' => 10,
				'title'    => esc_attr__( 'General', 'chiron' ),
			),	
			'header_panel' => array(
				'priority' => 15,
				'title'    => esc_attr__( 'Header', 'chiron' ),
			),			
		),

		'sections' => array(

			'header_logo_section' => array(
			    'title'          => esc_attr__( 'Logo', 'chiron' ),
			    'description' => '',
			    'panel'          => 'header_panel', // Not typically needed.
			    'priority'       => 50,
			    'capability'     => 'edit_theme_options',
			),

			'header_social_section' => array(
				'title'    => esc_attr__( 'Socials', 'chiron' ),
				'description' => '',
				'panel'          => 'header_panel', // Not typically needed.
				'priority'    => 60,
				'capability'  => 'edit_theme_options',
			),		

			'header_styling_section' => array(
				'title'    => esc_attr__( 'Styling', 'chiron' ),
				'description' => '',
				'panel'          => 'header_panel', // Not typically needed.
				'priority'    => 61,
				'capability'  => 'edit_theme_options',
			),

			// Section Blog
			'blog_section'     => array(
				'title'       => esc_attr__( 'Blog', 'chiron' ),
				'description' => '',
				'priority'    => 170,
				'capability'  => 'edit_theme_options',
			),

			// Section Footer
			'footer_section'     => array(
				'title'       => esc_attr__( 'Footer', 'chiron' ),
				'description' => '',
				'priority'    => 180,
				'capability'  => 'edit_theme_options',
			),

			// Section Styling
			'styling_section'     => array(
				'title'       => esc_attr__( 'Styling', 'chiron' ),
				'description' => '',
				'priority'    => 190,
				'capability'  => 'edit_theme_options',
			),
			
			'preload_section'     => array(
				'title'       => esc_attr__( 'Preload', 'chiron' ),
				'description' => '',
				'priority'    => 195,
				'capability'  => 'edit_theme_options',
			),

			'miscellaneous_section'     => array(
				'title'       => esc_attr__( 'Miscellaneous', 'chiron' ),
				'description' => '',
				'priority'    => 196,
				'capability'  => 'edit_theme_options',
			),			
		),

		'fields'   => array(

			// Preload
			'preload'     => array(
				'type'        => 'toggle',
				'label'       => esc_attr__( 'Preloader', 'chiron' ),
				'section'     => 'preload_section',
				'default'     => '1',
				'priority'    => 10,
			),
			'preload_bgcolor'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Color', 'chiron' ),
				'section'  => 'preload_section',
				'default'  => '#fff',
				'priority' => 10,
				'active_callback' => array(
					array(
					  	'setting'  => 'preload',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'preload_text_color'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Preload Color', 'chiron' ),
				'section'  => 'preload_section',
				'default'  => '#db4c17',
				'priority' => 10,
				'active_callback' => array(
					array(
					  	'setting'  => 'preload',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),

			// Header Logo
			'logo'         => array(
				'type'     => 'image',
				'label'    => esc_attr__( 'Logo Static', 'chiron' ),
				'description' => esc_attr__( 'Upload your logo static here', 'chiron' ),
				'section'  => 'header_logo_section',
				'default'  => trailingslashit( get_template_directory_uri() ) . 'assets/img/logo-dark.png',
				'priority' => 51,
			),		
			'logo_scroll'         => array(
				'type'     => 'image',
				'label'    => esc_attr__( 'Logo Scroll', 'chiron' ),
				'description' => esc_attr__( 'Upload your logo scroll here', 'chiron' ),
				'section'  => 'header_logo_section',
				'default'  => trailingslashit( get_template_directory_uri() ) . 'assets/img/logo-light.png',
				'priority' => 51,
			),	
				
			// Header Social
			'social_switch'     => array(
				'type'        => 'toggle',
				'label'       => esc_attr__( 'Social On/Off?', 'chiron' ),
				'section'     => 'header_social_section',
				'default'     => '1',
				'priority'    => 9,
			),
			'header_socials'     => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Socials Network', 'chiron' ),
				'section'  => 'header_social_section',
				'priority' => 10,
				'active_callback' => array(
					array(
					  	'setting'  => 'social_switch',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('social', 'chiron' ),
					'field' => 'social_name',
				),
				'default'  => array(),
				'fields'   => array(
					'social_name' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Social network name', 'chiron' ),
						'description' => esc_html__( 'This will be the social network name', 'chiron' ),
						'default'     => '',
					),
					'social_icon' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Icon class name', 'chiron' ),
						'description' => esc_html__( 'This will be the social icon: http://fontawesome.io/icons/', 'chiron' ),
						'default'     => '',
					),
					'social_link' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Link url', 'chiron' ),
						'description' => esc_html__( 'This will be the social link', 'chiron' ),
						'default'     => '',
					),
				),
			),
			
			// Header Styling
			'header_text_color'    => array(
				'type'     => 'color',
				'label'    => esc_attr__( 'Header Static Menu Item Color', 'chiron' ),
				'description' => esc_attr__( 'Set your header text color.', 'chiron' ),
				'section'     => 'header_styling_section',
				'default'     => '#000',
				'priority'    => 10,
				'choices'     => array(
					'alpha' => true,
				),
				'output' => array(
					array(
						'element'  => '.nav__list .sub-links li a',
						'property' => 'color',
					),
				),
			),
			'header_active_hover_text_color'    => array(
				'type'     => 'color',
				'label'    => esc_attr__( 'Header Active and Hover Menu Item Color', 'chiron' ),
				'description' => esc_attr__( 'Set your header active and hover text color.', 'chiron' ),
				'section'     => 'header_styling_section',
				'default'     => '#db4c17',
				'priority'    => 12,
				'choices'     => array(
					'alpha' => true,
				),
			),
			'header_bg'         => array(
				'type'     => 'color',
				'label'    => esc_attr__( 'Header Static Background Color', 'chiron' ),
				'description' => esc_attr__( 'Set your header background color.', 'chiron' ),
				'section'  => 'header_styling_section',
				'default'     => 'rgba(0,0,0,0)',
				'priority'    => 13,
				'choices'     => array(
					'alpha' => true,
				),
				'output' => array(
					array(
						'element'  => '.cd-header',
						'property' => 'background-color',
					),
				),
			),
			'header_scroll_bg' => array(
				'type'     => 'color',
				'label'    => esc_attr__( 'Header Scroll Background Color', 'chiron' ),
				'description' => esc_attr__( 'Set your header background color.', 'chiron' ),
				'section'  => 'header_styling_section',
				'default'     => 'rgba(255, 255, 255, 0.96)',
				'priority'    => 14,
				'choices'     => array(
					'alpha' => true,
				),
				'output' => array(
					array(
						'element'  => '.cd-header.is-fixed',
						'property' => 'background-color',
					),
				),
			),

			//Blog 
			'single_layout'     => array(
				'type'        => 'radio-image',				
				'label'       => esc_html__( 'Select Blog Layout', 'chiron' ),
				'section'     => 'blog_section',
				'default'     => 'right-bar',
				'priority'    => 8,
				'choices'     => array(
					'no-bar'  => get_template_directory_uri() . '/assets/img/theme-options/1c.png',
					'left-bar'   => get_template_directory_uri() . '/assets/img/theme-options/2cl.png',
					'right-bar' => get_template_directory_uri() . '/assets/img/theme-options/2cr.png',					
				),
			),
			'clientlogo_switch'     => array(
				'type'        => 'toggle',
				'label'       => esc_attr__( 'Client Lofo On/Off?', 'chiron' ),
				'section'     => 'blog_section',
				'default'     => '0',
				'priority'    => 9,
			),
			'clients_logo'     => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Client Lofo', 'chiron' ),
				'section'  => 'blog_section',
				'priority' => 10,
				'active_callback' => array(
					array(
					  	'setting'  => 'clientlogo_switch',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'default'  => array(),
				'fields'   => array(
					'logo_img' => array(
						'type'        => 'image',
						'label'       => esc_html__( 'logo image', 'chiron' ),
						'description' => esc_html__( 'This will be the logo image', 'chiron' ),
						'default'     => '',
					),
				),
			),
			
			// Footer
			'bg_ft'         => array(
				'type'     => 'image',
				'label'    => esc_attr__( 'Background Image Footer', 'chiron' ),
				'description' => esc_attr__( 'Upload your logo footer here', 'chiron' ),
				'section'  => 'footer_section',
				'default'  => trailingslashit( get_template_directory_uri() ) . 'assets/img/footer.jpg',
				'priority' => 10,
			),
			'logo_ft'         => array(
				'type'     => 'image',
				'label'    => esc_attr__( 'Logo Footer', 'chiron' ),
				'description' => esc_attr__( 'Upload your logo footer here', 'chiron' ),
				'section'  => 'footer_section',
				'default'  => trailingslashit( get_template_directory_uri() ) . 'assets/img/logo-light.png',
				'priority' => 10,
			),	
			'copyright'       => array(
				'type'        => 'textarea',
				'label'       => esc_html__( 'Text Left Footer Bottom', 'chiron' ),
				'section'     => 'footer_section',
				'default'     => 'Copyright 2019 - Chiron by IG Design',
				'priority'    => 10,				
			),
			'socialfooter_switch'     => array(
				'type'        => 'toggle',
				'label'       => esc_attr__( 'Social On/Off?', 'chiron' ),
				'section'     => 'footer_section',
				'default'     => '1',
				'priority'    => 9,
			),
			'footer_socials'     => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Socials Network', 'chiron' ),
				'section'  => 'footer_section',
				'priority' => 10,
				'active_callback' => array(
					array(
					  	'setting'  => 'social_switch',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('social', 'chiron' ),
					'field' => 'social_name',
				),
				'default'  => array(),
				'fields'   => array(
					'social_name' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Social network name', 'chiron' ),
						'description' => esc_html__( 'This will be the social network name', 'chiron' ),
						'default'     => '',
					),
					'social_link' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Link url', 'chiron' ),
						'description' => esc_html__( 'This will be the social link', 'chiron' ),
						'default'     => '',
					),
				),
			),

			//Styling Settings	
			'main_color'    => array(
				'type'     => 'color',
				'label'    => esc_attr__( 'Primary Color', 'chiron' ),
				'section'  => 'styling_section',
				'default'  => '#db4c17',
				'priority' => 10,
			),		

			//miscellaneous
			'mapapikey'     => array(
				'type'        => 'text',
				'label'       => esc_html__( 'Add Your Google Map API Key', 'chiron' ),
				'section'     => 'miscellaneous_section',
				'default'     => 'AIzaSyDpVQEdCmd9aY_-N6920-wilfScyBwS-Lw',
				'priority'    => 10,	
				'description' => 'Get an API Key here: https://developers.google.com/maps/documentation/javascript/get-api-key',			
			),
		),
	)
);

/**
 * Add color styling from theme
 */
function chiron_custom_styles_method() {
	$color = chiron_get_option('main_color'); //E.g. #6dc234
	$menu_hover_color = chiron_get_option('header_active_hover_text_color');
	$preloadbg = chiron_get_option('preload_bgcolor');
	$preloadcolor = chiron_get_option('preload_text_color');
    $custom_css = "
    	::selection {
			background:  {$color};
		}
		::-moz-selection {
			background:  {$color};
		}

		/* Color Default */

		.hero-center-text-wrap h2 strong,
		.hero-center-text-wrap h1 strong,
		.page-center-text-wrap h1 strong,
		.footer-social li a,
		.hero-top-text,
		.hero-center-text-wrap a:hover,
		.hero-center-text-wrap a i,
		.hero-center-text-wrap a:hover i,
		#filter li .current span,
		.tipper .tipper-content span,
		.typed-cursor,
		.quote h6,
		.list-social-team li.icon-team a:hover,
		.team-wrap,
		.contact-det,
		.blog-box .more:after,
		.list-style.circle li:before,
		.list-style.circle-o li:before,
		.list-style li i,
		.list-style a.btn-link:hover{
			color: {$color};
		}

		#royal_preloader.royal_preloader_progress .royal_preloader_meter,
		#owl-hero-1.owl-theme .owl-controls .owl-page.active span,
		#owl-hero-1.owl-theme .owl-controls .owl-page span:hover,
		#owl-sep-1.owl-theme .owl-controls .owl-page.active span,
		#owl-sep-1.owl-theme .owl-controls .owl-page span:hover,
		.video-button-hero,
		.color-list h6:before,
		#cd-zoom-in, #cd-zoom-out,
		.btn-primary,
		.btn-primary:hover,
		mark{
			background-color: {$color};
		}

		figure.vimeo a:before, figure.youtube a:before {
			border-left: 10px solid {$color};
		}
		figure.vimeo:hover a:after, figure.youtube:hover a:after {
			background:{$color};
		}
		.form-control:focus,
		.form-control:active{
			border-color: {$color};
		}
		.blockquote{
			border-left: 0.4rem solid {$color};
		}
		.blockquote-reverse{
			border-right: 0.4rem solid {$color};
		} 
		
		/* Menu Text hover and active */

		.menu ul li ul li.active > a, .menu ul li ul li.active a:hover, .cbp-af-header.cbp-af-header-shrink .menu ul li ul li.active > a,
		.cbp-af-header.cbp-af-header-shrink ul li ul li.active a:hover, .menu ul li ul li.current-menu-parent > a,
		.cbp-af-header.cbp-af-header-shrink .menu ul li ul li.current-menu-parent > a
		 {
		  color: {$menu_hover_color};
		}


		/* Preload #db4c17 */

		#royal_preloader.royal_preloader_progress .royal_preloader_meter {
			background-color: {$preloadcolor};
		}

		#royal_preloader {
			background-color: {$preloadbg}!important;
		}
		";

    wp_add_inline_style( 'chiron-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'chiron_custom_styles_method' );

