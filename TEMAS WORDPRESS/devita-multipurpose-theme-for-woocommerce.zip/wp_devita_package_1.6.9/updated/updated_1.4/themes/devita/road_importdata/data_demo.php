<?php 
$array_imports = array(
	'digital1' => array(
		'image' => 'screenshot',
		'page_name' => 'Digital Home 1',
		'is_default' => 1
	),
	'digital2' => array(
		'image' => 'screenshot2',
		'page_name' => 'Digital Home 2',
		
	),
	'digital3' => array(
		'image' => 'screenshot3',
		'page_name' => 'Digital Home 3',
		
	),
	'digital4' => array(
		'image' => 'screenshot4',
		'page_name' => 'Digital Home 4',
		
	),
	'medical1' => array(
		'image' => 'screenshot5',
		'page_name' => 'Medical Home 1',
		
	),
	'book1' => array(
		'image' => 'screenshot6',
		'page_name' => 'Book Home 1',
		
	),
	'book2' => array(
		'image' => 'screenshot7',
		'page_name' => 'Book Home 2',
		
	),	
	'coffee1' => array(
		'image' => 'screenshot8',
		'page_name' => 'Coffee Home 1',
		
	),
	'glasses1' => array(
		'image' => 'screenshot9',
		'page_name' => 'Glasses Home 1',
		
	),
	'watch1' => array(
		'image' => 'screenshot10',
		'page_name' => 'Watch Home 1',
		
	),
	'game1' => array(
		'image' => 'screenshot11',
		'page_name' => 'Game Home 1',
		
	),
	'contruction1' => array(
		'image' => 'screenshot12',
		'page_name' => 'Contruction Home 1',
		
	),
	'jewelry1' => array(
		'image' => 'screenshot13',
		'page_name' => 'Jewelry Home 1',
		
	), 
	'bike1' => array(
		'image' => 'screenshot14',
		'page_name' => 'Bike Home 1',
		
	), 
	'sport1' => array(
		'image' => 'screenshot15',
		'page_name' => 'Sport Home 1',
		
	),
	'watch1' => array(
		'image' => 'screenshot16',
		'page_name' => 'Fashion Home 1',
		
	),
	'furnilife1' => array(
		'image' => 'screenshot17',
		'page_name' => 'Furnilife Home 1',
		
	),
	'autoparts1' => array(
		'image' => 'screenshot18',
		'page_name' => 'Auto Part Home 1',
		
	),
	'organic' => array(
		'image' => 'screenshot19',
		'page_name' => 'Organic Home 1',
		
	),
	'petmarket' => array(
		'image' => 'screenshot20',
		'page_name' => 'Petmarket Home 1',
		
	),
);
$opt_name = 'devita_opt'; 					