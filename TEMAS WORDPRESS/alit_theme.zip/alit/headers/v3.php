<header id="apus-header" class="site-header header-v3 hidden-sm hidden-xs " role="banner">
    
    <div class="header-main clearfix">
        <div class="container">
            <div class="header-inner">
                <div class="row">
                    <div class="col-md-5 p-static">
                        <!-- search form -->
                        <div class="pull-left">
                            <div class="header-setting">
                                <?php get_template_part( 'page-templates/parts/productsearchform' ); ?>
                            </div>
                        </div>
                    </div>

                    <!-- LOGO -->
                    <div class="col-md-2">
                        <div class="logo-in-theme">
                            <?php get_template_part( 'page-templates/parts/logo' ); ?>
                        </div>
                    </div>

                    <div class="col-md-5 p-static">
                        <div class="heading-right pull-right hidden-sm hidden-xs">
                            <div class="pull-right  header-setting">

                                <!-- user info --> 
                                <?php if ( has_nav_menu( 'topmenu' ) ): ?>
                                    <div class="pull-right dropdown my-account">
                                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" role="button" aria-haspopup="true" data-delay="0" href="#" title="<?php esc_html_e('My Account', 'alit'); ?>">
                                            <img  src="<?php echo esc_url_raw( get_template_directory_uri().'/images/account-icon.png'); ?>" alt="">
                                        </a>
                                        <div class="dropdown-menu">
                                            
                                                <nav class="apus-topmenu" role="navigation">
                                                    <?php
                                                        $args = array(
                                                            'theme_location'  => 'topmenu',
                                                            'menu_class'      => 'apus-menu-top',
                                                            'fallback_cb'     => '',
                                                            'menu_id'         => 'topmenu'
                                                        );
                                                        wp_nav_menu($args);
                                                    ?>
                                                </nav>
                                            
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- cart mini -->
                                <?php if ( defined('ALIT_WOOCOMMERCE_ACTIVED') && ALIT_WOOCOMMERCE_ACTIVED ): ?>
                                    <div class="pull-right">
                                        <div class="top-cart hidden-xs">
                                            <?php get_template_part( 'woocommerce/cart/mini-cart-button' ); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="<?php echo (alit_get_config('keep_header') ? 'main-sticky-header-wrapper' : ''); ?>">
        <div class="header-menu <?php echo (alit_get_config('keep_header') ? 'main-sticky-header' : ''); ?>">
            <div class="container">
                <div class="p-static ">
                    <?php if ( has_nav_menu( 'primaryfull' ) ) : ?>
                        <div class="main-menu  text-center">
                            <nav 
                             data-duration="400" class="hidden-xs hidden-sm apus-megamenu slide animate navbar" role="navigation">
                            <?php   $args = array(
                                    'theme_location' => 'primaryfull',
                                    'container_class' => 'collapse navbar-collapse ',
                                    'menu_class' => 'nav navbar-nav megamenu main-menu-v1',
                                    'fallback_cb' => '',
                                    'menu_id' => 'primary-menu',
                                    'walker' => new Alit_Nav_Menu()
                                );
                                wp_nav_menu($args);
                            ?>
                            </nav>
                        </div>

                    <?php elseif ( has_nav_menu( 'primary' ) ) : ?>
                        <nav 
                         data-duration="400" class="hidden-xs hidden-sm apus-megamenu slide animate navbar" role="navigation">
                        <?php   $args = array(
                                'theme_location' => 'primary',
                                'container_class' => 'collapse navbar-collapse',
                                'menu_class' => 'nav navbar-nav megamenu main-menu-v1',
                                'fallback_cb' => '',
                                'menu_id' => 'primary-menu',
                                'walker' => new Alit_Nav_Menu()
                            );
                            wp_nav_menu($args);
                        ?>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</header>