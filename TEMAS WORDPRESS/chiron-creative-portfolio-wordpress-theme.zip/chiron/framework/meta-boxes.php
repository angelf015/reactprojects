<?php

/**
 * Register meta boxes
 *
 * @since 1.0
 *
 * @param array $meta_boxes
 *
 * @return array
 */
if ( is_admin() ) {
	function chiron_register_meta_boxes( $meta_boxes ) {

		$prefix = '_cmb_';

		$meta_boxes[] = array(
			'id'       => 'format_detail',
			'title'    => __( 'Format Details', 'chiron' ),
			'pages'    => array( 'post' ),
			'context'  => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields'   => array(
				array(
					'name'             => __( 'Image', 'chiron' ),
					'id'               => $prefix . 'image',
					'type'             => 'image_advanced',
					'class'            => 'image',
					'max_file_uploads' => 1,
				),
				array(
					'name'  => __( 'Gallery', 'chiron' ),
					'id'    => $prefix . 'images',
					'type'  => 'image_advanced',
					'class' => 'gallery',
				),			
				array(				
					'name'  => __( 'Audio', 'chiron' ),
					'id'    => $prefix . 'link_audio', // How to display on front end: https://metabox.io/docs/get-meta-value/
					'type'  => 'oembed',
					// Allow to clone? Default is false
					'clone' => false,
					// Input size
					'size'  => 30,
					'class' => 'audio',
					'desc' => 'Example: https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/139083759',
				),
				array(
					'name'  => __( 'Video', 'chiron' ),
					'id'    => $prefix . 'link_video', // How to display on front end: https://metabox.io/docs/get-meta-value/
					'type'  => 'oembed',
					// Allow to clone? Default is false
					'clone' => false,
					// Input size
					'size'  => 30,
					'class' => 'video',
					'desc' => 'Example: <b>http://www.youtube.com/embed/0ecv0bT9DEo</b> or <b>http://player.vimeo.com/video/47355798</b>',
				),		
			),
		);

		$meta_boxes[] = array(
			'id'       => 'page_detail',
			'title'    => __( 'Page Details', 'chiron' ),
			'pages'    => array( 'page','post' ),
			'context'  => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields'   => array(
				array(
					'name'             => esc_html__( 'Subtitle', 'chiron' ),
					'id'               => $prefix . 'subtitle',
					'type'             => 'textarea',	
				),	
			),
		);

		$meta_boxes[] = array(
			'id'       => 'portfolio_detail',
			'title'    => __( 'Portfolio Details', 'chiron' ),
			'pages'    => array( 'portfolio' ),
			'context'  => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields'   => array(	
				array(
					'name'             => esc_html__( 'Upload image for detailt content', 'chiron' ),
					'id'               => $prefix . 'poster_image',
					'type'             => 'image_advanced',			
					'max_file_uploads' => 1,
					'desc' => 'Use for Portfolio Motion Hover Effect element',
				),		
				array(
					'name'             => esc_html__( 'Info item', 'chiron' ),
					'id'               => $prefix . 'color_item',
					'type'             => 'text',	
				),		
				array(
					'name'             => esc_html__( 'detail', 'chiron' ),
					'id'               => $prefix . 'detail_item',
					'type'             => 'textarea',	
				),	
			),
		);

		return $meta_boxes;
	}
	add_filter( 'rwmb_meta_boxes', 'chiron_register_meta_boxes' );
}