<?php
/**
 * Hooks for importer
 *
 * @package Chiron
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function chiron_importer() {
    return array(
        array(
            'name'       => 'Main Demo',
            'preview'    => get_template_directory_uri() . '/framework/data/screenshot.png',
            'content'    => get_template_directory_uri() . '/framework/data/demo-content.xml',
            'customizer' => get_template_directory_uri() . '/framework/data/customizer.dat',
            'widgets'    => get_template_directory_uri() . '/framework/data/widgets.wie',                       
            'pages'      => array(
                'front_page' => 'Home Motion Hover Effect',
                'blog'       => '<strong>-</strong> latest news <strong>-</strong><br><span>journal</span>',                 
            ),
            'menus'      => array(
                'primary'      => 'main-menu',                
            ),
        ),
    );
}
add_filter( 'soo_demo_packages', 'chiron_importer', 30 );