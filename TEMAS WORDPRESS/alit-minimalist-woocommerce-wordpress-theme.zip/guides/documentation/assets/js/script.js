/*!
 * Documenter 2.0
 * http://rxa.li/documenter
 *
 * Copyright 2011, Xaver Birsak
 * http://revaxarts.com
 *
 */
 
jQuery(document).ready(function($){
	jQuery('.sidebar-action').bind('click',function(){
		$('#documenter_sidebar').toggleClass('active');
		
	});
});