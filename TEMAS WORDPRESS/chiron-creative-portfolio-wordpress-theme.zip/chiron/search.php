<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WordPress
 * @subpackage chiron
 * @since 1.0
 * @version 1.0
 */
get_header(); ?>


<!-- subheader begin -->
<div class="section padding-top-hero padding-bottom-big over-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-center-text-wrap text-center">
                <?php if ( have_posts() ) : ?>
                    <h1><?php printf( esc_html__( 'Search Results for: %s', 'chiron' ), '<br><span>' . get_search_query() . '</span>' ); ?></h1>
                <?php else : ?>
                    <h1><span><?php esc_html_e( 'Nothing Found', 'chiron' ); ?></span></h1>
                <?php endif; ?>
            </div>  
        </div>      
    </div>  
</div> 
<!-- subheader close -->

<!-- content begin -->
<div class="section padding-bottom-big">
    <div class="container-fluid">
        <div id="blog-grid">
        <?php
        if ( have_posts() ) :
        	/* Start the Loop */
        	while ( have_posts() ) : the_post();

        		/**
        		 * Run the loop for the search to output the results.
        		 * If you want to overload this in a child theme then include a file
        		 * called content-search.php and that will be used instead.
        		 */
        		get_template_part( 'template-parts/post/content', get_post_format() );

        	endwhile; // End of the loop.

        else : ?>
    	<p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'chiron' ); ?></p>
    	
    	<?php get_search_form(); ?>
        <?php endif; ?>  
        </div>
    </div>
</div> 

<?php if ($wp_query->max_num_pages > 1) { ?>
<div class="section padding-top-bottom-small">
    <div class="container">
        <div class="row">
            <div class="col-md-12 pagination-full">
                <div class="project-nav-wrap">
                    <div class="col-md-6 col-6 right-align"><?php previous_posts_link( '<div class="left-nav" data-scroll-reveal="enter left move 60px over 0.9s after 0.1s">'. esc_html__( 'new', 'chiron' ) .'<div class="text-on-hover">'. esc_html__( 'new entries', 'chiron' ) .'</div></div>' ); ?></div>
                    <div class="col-md-6 col-6 left-align"><?php next_posts_link( '<div class="right-nav" data-scroll-reveal="enter right move 60px over 0.9s after 0.1s">'. esc_html__( 'old', 'chiron' ) .'<div class="text-on-hover">'. esc_html__( 'older entries', 'chiron' ) .'</div></div>' ); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<!-- content close -->
<?php get_footer();
